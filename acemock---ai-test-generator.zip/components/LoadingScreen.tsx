import React from 'react';
import { Loader2 } from 'lucide-react';

interface LoadingScreenProps {
  topic: string;
}

export const LoadingScreen: React.FC<LoadingScreenProps> = ({ topic }) => {
  return (
    <div className="flex flex-col items-center justify-center min-h-[50vh] text-center p-8">
      <div className="relative mb-8">
        <div className="absolute inset-0 bg-primary-500 blur-xl opacity-20 rounded-full animate-pulse"></div>
        <div className="bg-white p-4 rounded-full shadow-lg relative z-10">
          <Loader2 className="w-10 h-10 text-primary-600 animate-spin" />
        </div>
      </div>
      <h2 className="text-2xl font-bold text-slate-800 mb-3">Crafting your Quiz</h2>
      <p className="text-slate-500 max-w-md">
        Gemini is analyzing the topic <span className="font-semibold text-primary-600">"{topic}"</span> and preparing challenging questions for you...
      </p>
    </div>
  );
};