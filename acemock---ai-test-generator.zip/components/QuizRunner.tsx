import React, { useState } from 'react';
import { Question } from '../types';
import { ChevronRight, CheckCircle2, Circle } from 'lucide-react';

interface QuizRunnerProps {
  questions: Question[];
  onFinish: (answers: number[]) => void;
}

export const QuizRunner: React.FC<QuizRunnerProps> = ({ questions, onFinish }) => {
  const [currentIndex, setCurrentIndex] = useState(0);
  const [selectedAnswers, setSelectedAnswers] = useState<number[]>(new Array(questions.length).fill(-1));

  const currentQuestion = questions[currentIndex];
  const progress = ((currentIndex + 1) / questions.length) * 100;

  const handleSelect = (optionIndex: number) => {
    const newAnswers = [...selectedAnswers];
    newAnswers[currentIndex] = optionIndex;
    setSelectedAnswers(newAnswers);
  };

  const handleNext = () => {
    if (currentIndex < questions.length - 1) {
      setCurrentIndex(prev => prev + 1);
    } else {
      onFinish(selectedAnswers);
    }
  };

  return (
    <div className="w-full max-w-2xl mx-auto">
      {/* Progress Header */}
      <div className="bg-white rounded-xl shadow-sm border border-slate-200 p-6 mb-6">
        <div className="flex justify-between items-center mb-4">
          <span className="text-sm font-medium text-slate-500">Question {currentIndex + 1} of {questions.length}</span>
          <span className="text-sm font-bold text-primary-600">{Math.round(progress)}% Completed</span>
        </div>
        <div className="w-full h-2 bg-slate-100 rounded-full overflow-hidden">
          <div 
            className="h-full bg-primary-500 transition-all duration-500 ease-out"
            style={{ width: `${progress}%` }}
          />
        </div>
      </div>

      {/* Question Card */}
      <div className="bg-white rounded-xl shadow-lg border border-slate-200 overflow-hidden">
        <div className="p-8">
          <h2 className="text-xl font-bold text-slate-800 mb-6 leading-relaxed">
            {currentQuestion.text}
          </h2>

          <div className="space-y-3">
            {currentQuestion.options.map((option, idx) => (
              <button
                key={idx}
                onClick={() => handleSelect(idx)}
                className={`w-full text-left p-4 rounded-xl border-2 transition-all duration-200 flex items-center group ${
                  selectedAnswers[currentIndex] === idx
                    ? 'border-primary-500 bg-primary-50 shadow-md'
                    : 'border-slate-100 hover:border-primary-200 hover:bg-slate-50'
                }`}
              >
                <div className={`w-6 h-6 rounded-full border-2 mr-4 flex items-center justify-center flex-shrink-0 transition-colors ${
                  selectedAnswers[currentIndex] === idx
                    ? 'border-primary-500 bg-primary-500 text-white'
                    : 'border-slate-300 text-transparent group-hover:border-primary-300'
                }`}>
                  {selectedAnswers[currentIndex] === idx && <CheckCircle2 className="w-4 h-4" />}
                </div>
                <span className={`text-base ${
                  selectedAnswers[currentIndex] === idx ? 'text-primary-900 font-medium' : 'text-slate-600'
                }`}>
                  {option}
                </span>
              </button>
            ))}
          </div>
        </div>

        <div className="bg-slate-50 p-6 border-t border-slate-100 flex justify-end">
          <button
            onClick={handleNext}
            disabled={selectedAnswers[currentIndex] === -1}
            className="bg-primary-600 hover:bg-primary-700 disabled:opacity-50 disabled:cursor-not-allowed text-white font-semibold py-3 px-8 rounded-lg transition-all flex items-center gap-2 shadow-md hover:shadow-lg transform active:scale-95"
          >
            {currentIndex === questions.length - 1 ? 'Finish Test' : 'Next Question'}
            <ChevronRight className="w-4 h-4" />
          </button>
        </div>
      </div>
    </div>
  );
};