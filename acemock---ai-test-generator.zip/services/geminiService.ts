import { GoogleGenAI, Type } from "@google/genai";
import { Question, Difficulty } from '../types';

const ai = new GoogleGenAI({ apiKey: process.env.API_KEY });

export const generateQuestions = async (
  topic: string,
  difficulty: Difficulty,
  count: number
): Promise<Question[]> => {
  try {
    const prompt = `Generate a mock test with ${count} multiple-choice questions about "${topic}" at a ${difficulty} difficulty level. 
    Each question must have exactly 4 options. 
    Ensure the questions are challenging and accurate.`;

    const response = await ai.models.generateContent({
      model: 'gemini-3-flash-preview',
      contents: prompt,
      config: {
        responseMimeType: 'application/json',
        responseSchema: {
          type: Type.ARRAY,
          items: {
            type: Type.OBJECT,
            properties: {
              text: {
                type: Type.STRING,
                description: 'The question text',
              },
              options: {
                type: Type.ARRAY,
                items: { type: Type.STRING },
                description: 'An array of exactly 4 possible answers',
              },
              correctAnswerIndex: {
                type: Type.INTEGER,
                description: 'The zero-based index of the correct answer (0-3)',
              },
              explanation: {
                type: Type.STRING,
                description: 'A brief explanation of why the correct answer is correct',
              },
            },
            required: ['text', 'options', 'correctAnswerIndex', 'explanation'],
          },
        },
      },
    });

    if (!response.text) {
      throw new Error("No data returned from Gemini");
    }

    const rawData = JSON.parse(response.text);
    
    // Add IDs to the questions for React keys
    const questions: Question[] = rawData.map((q: any, index: number) => ({
      id: index,
      text: q.text,
      options: q.options,
      correctAnswerIndex: q.correctAnswerIndex,
      explanation: q.explanation
    }));

    return questions;
  } catch (error) {
    console.error("Failed to generate quiz:", error);
    throw error;
  }
};